package sprint1_final;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

// Id 82201188
public class B {

    private static Integer getPointCount(int keysNumber, List<char[]> matrix) {
        int realKeysNumber = keysNumber * 2;// 2 мальчика
        int pointCounter = 0;

        HashMap<Integer, Integer> numbersMap = getNumbersMap(matrix);

        for (int t = 0; t < 10; t++) {
            if (numbersMap.get(t) != null && numbersMap.get(t) <= realKeysNumber) {
                pointCounter++;
            }
        }

        return pointCounter;
    }

    private static HashMap<Integer, Integer> getNumbersMap(List<char[]> matrix) {
        HashMap<Integer, Integer> numbersMap = new HashMap<>();
        for (int i = 0; i < matrix.size(); i++) {
            for (int j = 0; j < matrix.get(0).length; j++) {
                Character value = matrix.get(i)[j];
                if (value.equals('.')) {
                    continue;
                }

                Integer intValue = Character.getNumericValue(value);
                Integer mapNumber = numbersMap.get(intValue);
                if (mapNumber != null) {
                    numbersMap.put(intValue, mapNumber + 1);
                } else {
                    numbersMap.put(intValue, 1);
                }
            }
        }
        return numbersMap;
    }

    public static void main(String[] args) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            int keysNumber = readInt(reader);
            List<char[]> matrix = readMatrix(reader, 4);
            Integer points = getPointCount(keysNumber, matrix);
            System.out.print(points);
        }
    }

    private static int readInt(BufferedReader reader) throws IOException {
        return Integer.parseInt(reader.readLine());
    }

    private static char[] readList(BufferedReader reader) throws IOException {
        return reader.readLine().toCharArray();
    }

    private static List<char[]> readMatrix(BufferedReader reader, int rowsCount) throws IOException {
        List<char[]> matrix = new ArrayList<>(rowsCount);
        for (int i = 0; i < rowsCount; i++) {
            matrix.add(readList(reader));
        }
        return matrix;
    }
}
