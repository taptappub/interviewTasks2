package sprint2_final;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
-- ПРИНЦИП РАБОТЫ --
Дек реализован на основе массива, на кольцевом буффере.
Основная задумка в том, что при добавлении и удалении есть 2 состояния:
1) дек пуст
2) дек не пуст
Если дек пуст, то указатели на начало и конец при добавлении элемента не меняются, а если нет, то
алгоритм добавляет в соседнюю по кольцу ячейку. Проверять пересечение указателей слева (pointerLeft)
и справа (pointerRight) нет необходимости, т.к. в случае пересечения размер дека (size) будет больше
вместимости (capacity), и алгоритм вернет ошибку.

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Т.к. при добавлении и удалении нет сдвига элементов массива и прочих манипуляций, а только рассчитываются
указатели pointerLeft и pointerRight за один проход, то сложность каждого метода в Дек равна O(1)

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --
Дек основывается на массив длинной n, и максимально может быть заполнено размером size, где
size <= n.
Поэтому дек будет потреблять O(n) памяти.
*/

//https://contest.yandex.ru/contest/22781/run-report/82596660/
public class A {

    public static void main(String[] args) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(System.out))) {

            int n = readInt(reader);
            int k = readInt(reader);
            Dec dec = new Dec(k);

            for (int i = 0; i < n; i++) {

                List<String> rawAction = readList(reader);

                switch (rawAction.get(0)) {
                    case "push_front" :{
                        try {
                            int value = Integer.parseInt(rawAction.get(1));
                            dec.push_front(value);
                        } catch (IllegalStateException e) {
                            writer.write("error");
                            writer.newLine();
                        }
                        break;
                    }
                    case "push_back":{
                        try {
                            int value = Integer.parseInt(rawAction.get(1));
                            dec.push_back(value);
                        } catch (IllegalStateException e) {
                            writer.write("error");
                            writer.newLine();
                        }
                        break;
                    }
                    case "pop_front" : {
                        try {
                            int value = dec.pop_front();
                            writer.write(value + "");
                            writer.newLine();
                        } catch (IllegalStateException e) {
                            writer.write("error");
                            writer.newLine();
                        }
                        break;
                    }
                    case "pop_back" : {
                        try {
                            int value = dec.pop_back();
                            writer.write(value + "");
                            writer.newLine();
                        } catch (IllegalStateException e) {
                            writer.write("error");
                            writer.newLine();
                        }
                        break;
                    }
                }
            }
        }
    }

    private static int readInt(BufferedReader reader) throws IOException {
        return Integer.parseInt(reader.readLine());
    }

    private static List<String> readList(BufferedReader reader) throws IOException {

        return new ArrayList<>(Arrays.asList(reader.readLine().split(" ")));
    }

    public static class Dec {

        private final int[] array;
        private int pointerLeft = 0;
        private int pointerRight = 0;
        private int size;
        private final int capacity;

        public Dec(int capacity) {
            this.capacity = capacity;
            this.size = 0;
            this.array = new int[capacity];
        }

        /**
         * O(1)
         */
        public void push_back(int value) {
            if (size == capacity) {
                throw new IllegalStateException();
            }

            if (size > 0) {
                pointerRight = (pointerRight + 1) % capacity;
            }
            array[pointerRight] = value;
            size++;
        }

        /**
         * O(N)
         */
        public void push_front(int value) {
            if (size == capacity) {
                throw new IllegalStateException();
            }

            if (size > 0) {
                if (pointerLeft - 1 < 0) {
                    pointerLeft = capacity - 1;
                } else {
                    pointerLeft = pointerLeft - 1;
                }
            }
            array[pointerLeft] = value;
            size++;
        }

        /**
         * O(1)
         */
        public int pop_front() {
            if (size == 0) {
                throw new IllegalStateException();
            }

            int value = array[pointerLeft];
            size--;

            if (size != 0) {
                pointerLeft = (pointerLeft + 1) % capacity;
            }
            return value;
        }

        /**
         * O(1)
         */
        public int pop_back() {
            if (size == 0) {
                throw new IllegalStateException();
            }

            int value = array[pointerRight];
            size--;

            if (size != 0) {
                if (pointerRight - 1 < 0) {
                    pointerRight = capacity - 1;
                } else {
                    pointerRight = pointerRight - 1;
                }
            }

            return value;
        }
    }
}

/*
14
3
push_back 1
push_front 2
push_front 3
push_front 4
pop_front
pop_front
pop_front
push_back 5
push_front 6
push_front 7
pop_back
pop_back
pop_back
pop_back
 */